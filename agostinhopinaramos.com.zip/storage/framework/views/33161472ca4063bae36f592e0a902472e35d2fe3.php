<?php echo e($slot); ?>

<?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
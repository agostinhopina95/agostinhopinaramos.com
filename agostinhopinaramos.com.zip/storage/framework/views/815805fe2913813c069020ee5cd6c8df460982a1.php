<?php
$obj = [
    "copyright" => '<p>All Right Reserved AgostinhoPinaRamos © 2020 by <a href="https://goodshapecode.com/" >Goodshapecode</a></p>',
    "social_networks" => [
        [
            "icon" => "fa fa-linkedin",
            "href" => "https://www.linkedin.com/in/agostinhopinaramos/"
        ],
        [
            "icon" => "fa fa-github",
            "href" => "https://github.com/agostinhopina95/"
        ],
        [
            "icon" => "fa fa-medium",
            "href" => "https://medium.com/@agostinhopina095"
        ],
    ],
    "skill" => [
        "last_update" => "05/11/2020 10:48",
        "technical" => [
            [
                "name" => "HTML/CSS3",
                "year" => 4.5,
                "point" => 4
            ],
            [
                "name" => "JavaScript",
                "year" => 4,
                "point" => 4.5
            ],
            [
                "name" => "PHP",
                "year" => 3,
                "point" => 4
            ],
            [
                "name" => "Python",
                "year" => 3,
                "point" => 3
            ],
            [
                "name" => "Java/Android",
                "year" => 4,
                "point" => 3
            ],
            [
                "name" => "Kotlin",
                "year" => 0,
                "point" => 1
            ],
            [
                "name" => "C#/ASP.NET",
                "year" => 2.5,
                "point" => 3
            ],
            [
                "name" => "C/C++",
                "year" => 3,
                "point" => 2.5
            ],
        ],
        "professional" => [
            [
                "name" => "Communication",
                "point" => 2.5,
            ],
            [
                "name" => "Team Work",
                "point" => 4.4,
            ],
            [
                "name" => "Project Management",
                "point" => 2.25,
            ],
            [
                "name" => "Creativity",
                "point" => 3.75,
            ],
        ],
    ],
    "experience" => [
        "education" => [
            [
                "name" => "Polytechnic Institute of Guarda",
                "course" => "Computer Science and Engineering",
                "interval" => "18/10/2017 – Current",
                "address" => "Av. Dr. Francisco Sá Carneiro 50, Guarda, Portugal",
                "url" => "http://www.estg.ipg.pt/",
            ],
            [
                "name" => "Politechnika Lubelska",
                "course" => "Computer Science and Engineering",
                "interval" => "17/02/2019 – 23/06/2019",
                "address" => "ul. Nadbystrzycka 38 D, Lublin, Poland",
                "url" => "http://www.pollub.pl/",
            ]
        ],
        "project" => [
            [
                "name" => "Testing COVID-19",
                "interval" => "23/04/2020 – 14/07/2020",
                "description" => 
                    "<p>Developed an android application that can evaluate if the user of the application have COVID-19 symptoms or something similar.</p>" .
                    "<p>Planned a project involving AI to improve system response based on doctor's information.</p>" .
                    "<p>Created tool to compare and synchronize data from MySQL and SQLite databases automatically.</p>"
                ,
                "url" => "https://github.com/agostinhopina95/Testing_COVID_19",
                "skill" => ["Android", "PHP", "MariaDB", "SQLitle"],
            ]
        ],
        "work" => [
            [
                "name" => "Microsegur",
                "area" => "Developer",
                "interval" => "02/12/2020 – Current",
                "responsibility" => [
                    "IoT – Internet of Things",
                ],
                "url" => "https://microsegur.pt/",
                "skill" => ["NodeJS", "PHP", "HTML/CSS3", "JavaScript"],
            ]
        ]
    ],
];
?>
 <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('Header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <!-- Start Loader -->
    <div class="section-loader">
        <div class="loader">
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- End Loader -->

     <?php if (isset($component)) { $__componentOriginal4a33d2fa1442abbd06630fa81a083fdd536c12e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetNavbar::class, []); ?>
<?php $component->withName('Widget-Navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4a33d2fa1442abbd06630fa81a083fdd536c12e6)): ?>
<?php $component = $__componentOriginal4a33d2fa1442abbd06630fa81a083fdd536c12e6; ?>
<?php unset($__componentOriginal4a33d2fa1442abbd06630fa81a083fdd536c12e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

     <?php if (isset($component)) { $__componentOriginal118f2a3704478c795d033c6feee5a823d427e0b3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetHome::class, ['obj' => $obj]); ?>
<?php $component->withName('Widget-Home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal118f2a3704478c795d033c6feee5a823d427e0b3)): ?>
<?php $component = $__componentOriginal118f2a3704478c795d033c6feee5a823d427e0b3; ?>
<?php unset($__componentOriginal118f2a3704478c795d033c6feee5a823d427e0b3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

     <?php if (isset($component)) { $__componentOriginalc42942fbca0bd6d39da2e66a90a5c54a90af822a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetPortfolio::class, []); ?>
<?php $component->withName('Widget-Portfolio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc42942fbca0bd6d39da2e66a90a5c54a90af822a)): ?>
<?php $component = $__componentOriginalc42942fbca0bd6d39da2e66a90a5c54a90af822a; ?>
<?php unset($__componentOriginalc42942fbca0bd6d39da2e66a90a5c54a90af822a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

     <?php if (isset($component)) { $__componentOriginal790bf33a2982b21525c5daf55a00a61fed52e623 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetSkills::class, ['obj' => $obj]); ?>
<?php $component->withName('Widget-Skills'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal790bf33a2982b21525c5daf55a00a61fed52e623)): ?>
<?php $component = $__componentOriginal790bf33a2982b21525c5daf55a00a61fed52e623; ?>
<?php unset($__componentOriginal790bf33a2982b21525c5daf55a00a61fed52e623); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

     <?php if (isset($component)) { $__componentOriginal0e04616aa6f9d15e2a419f927a57d0a03de1426d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetExperiences::class, ['obj' => $obj]); ?>
<?php $component->withName('Widget-Experiences'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0e04616aa6f9d15e2a419f927a57d0a03de1426d)): ?>
<?php $component = $__componentOriginal0e04616aa6f9d15e2a419f927a57d0a03de1426d; ?>
<?php unset($__componentOriginal0e04616aa6f9d15e2a419f927a57d0a03de1426d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <?php if(false): ?>
     <?php if (isset($component)) { $__componentOriginalafaa64328895098b3d5d777b55bcec11a2d77e78 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetAbout::class, []); ?>
<?php $component->withName('Widget-About'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalafaa64328895098b3d5d777b55bcec11a2d77e78)): ?>
<?php $component = $__componentOriginalafaa64328895098b3d5d777b55bcec11a2d77e78; ?>
<?php unset($__componentOriginalafaa64328895098b3d5d777b55bcec11a2d77e78); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginale04df79112a0dc888aab277b9bd4a4ab15f37fba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetService::class, []); ?>
<?php $component->withName('Widget-Service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale04df79112a0dc888aab277b9bd4a4ab15f37fba)): ?>
<?php $component = $__componentOriginale04df79112a0dc888aab277b9bd4a4ab15f37fba; ?>
<?php unset($__componentOriginale04df79112a0dc888aab277b9bd4a4ab15f37fba); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginala5479e9dc1a8ae2e07575c5ac01322cefbc72895 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetPricing::class, []); ?>
<?php $component->withName('Widget-Pricing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginala5479e9dc1a8ae2e07575c5ac01322cefbc72895)): ?>
<?php $component = $__componentOriginala5479e9dc1a8ae2e07575c5ac01322cefbc72895; ?>
<?php unset($__componentOriginala5479e9dc1a8ae2e07575c5ac01322cefbc72895); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal0700a231134764afafc4c1c2f1f5434dcfc90ab9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetBlog::class, []); ?>
<?php $component->withName('Widget-Blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0700a231134764afafc4c1c2f1f5434dcfc90ab9)): ?>
<?php $component = $__componentOriginal0700a231134764afafc4c1c2f1f5434dcfc90ab9; ?>
<?php unset($__componentOriginal0700a231134764afafc4c1c2f1f5434dcfc90ab9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal57755dfe58c39da1e701cff166122b84cf89c18f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetTestimonials::class, []); ?>
<?php $component->withName('Widget-Testimonials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal57755dfe58c39da1e701cff166122b84cf89c18f)): ?>
<?php $component = $__componentOriginal57755dfe58c39da1e701cff166122b84cf89c18f; ?>
<?php unset($__componentOriginal57755dfe58c39da1e701cff166122b84cf89c18f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>

     <?php if (isset($component)) { $__componentOriginal490ca1faab79af867cd9e5088ce8da0230b8139d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WidgetFooter::class, ['obj' => $obj]); ?>
<?php $component->withName('Widget-Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal490ca1faab79af867cd9e5088ce8da0230b8139d)): ?>
<?php $component = $__componentOriginal490ca1faab79af867cd9e5088ce8da0230b8139d; ?>
<?php unset($__componentOriginal490ca1faab79af867cd9e5088ce8da0230b8139d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

 <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/index.blade.php ENDPATH**/ ?>
<?php
$categories = [
   [
      "name" => "Website",
      "id" => "website",
   ],
   [
      "name" => "Mobile",
      "id" => "mobile",
   ],
   [
      "name" => "Schema",
      "id" => "schema",
   ],
   [
      "name" => "Web application",
      "id" => "webapplication",
   ],
];

$manifest_directory =  __DIR__ . "/../../../public" . '/storage/project/manifest/';
$scanned_directory = array_diff(scandir($manifest_directory), array('..', '.'));
$projects = [];
foreach($scanned_directory as $file){
   $projects[] = explode(".json", $file)[0];
};
$articles = [];
foreach($projects as $project){
   $manifest = file_get_contents( $manifest_directory . $project . '.json' );
   $articles[] = json_decode($manifest, true);
}

?>

<?php $id_modal_hide = $id_modal = 0; ?>
<section class="mh-portfolio" id="mh-portfolio">
   <div class="container">
      <div class="row section-separator">
         <div class="section-title col-sm-12 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
            <h3>My Portfolio</h3>
         </div>
         <div class="part col-sm-12">
            <div class="portfolio-nav col-sm-12" id="filter-button">
               <ul>
                  <li data-filter="*" class="current wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s"> <span>All Categories</span></li>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li data-filter=".<?php echo e($category["id"]); ?>" class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s"><span><?php echo e($category["name"]); ?></span></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </div>
            <div class="mh-project-gallery col-sm-12 wow fadeInUp" id="project-gallery" data-wow-duration="0.8s" data-wow-delay="0.5s">
               <div class="portfolioContainer row">
                  <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="grid-item col-md-4 col-sm-6 col-xs-12 <?php echo e($article["category"]); ?>">
                     <figure>
                        <img src="<?php echo e($article["thumbnail"][0]); ?>" alt="<?php echo e($article["thumbnail"][1]); ?>">
                        <figcaption class="fig-caption">
                           <i class="fa fa-search"></i>
                           <h5 class="title"><?php echo e($article["title"]); ?></h5>
                           <span class="sub-title"><?php echo e($article["subtitle"]); ?></span>
                           <a data-fancybox data-src="#modal<?php echo e(md5($id_modal)); ?>"></a>
                        </figcaption>
                     </figure>
                  </div>
                  <?php
                  $id_modal++;
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
               <!-- End: .grid .project-gallery -->
            </div>
            <!-- End: .grid .project-gallery -->
         </div>
         <!-- End: .part -->
      </div>
      <!-- End: .row -->
   </div>
   <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="mh-portfolio-modal" id="modal<?php echo e(md5($id_modal_hide)); ?>">
      <div class="container">
         <div class="row mh-portfolio-modal-inner">
            <div class="col-sm-5">
               <h2><?php echo e($article["more"]["title"]); ?></h2>
               <div style="text-align: justify;text-justify: inter-word;" >
               <?php echo $article["more"]["description"]; ?>

               </div>
               <div class="mh-about-tag">
                  <ul>
                     <?php $__currentLoopData = $article["more"]["tecnology"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><span><?php echo e($tecnology); ?></span></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </div>
               <?php if(isset($article["more"]["demo"])): ?>
               <a target="_blank" href="<?php echo e($article["more"]["demo"]); ?>" class="btn btn-fill"><i class="fa fa-play" ></i>&nbsp; Demo</a>
               <?php endif; ?>
            </div>
            <div class="col-sm-7">
               <div class="mh-portfolio-modal-img">
                  <?php $__currentLoopData = $article["more"]["figure"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $figure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="tutorial">
                     <img src="<?php echo e($figure["img"]); ?>" alt="<?php echo e($article["thumbnail"][1]); ?>" class="img-fluid">
                     <p><?php echo e($figure["description"]); ?></p>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php
   $id_modal_hide++;
   ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/widget-portfolio.blade.php ENDPATH**/ ?>
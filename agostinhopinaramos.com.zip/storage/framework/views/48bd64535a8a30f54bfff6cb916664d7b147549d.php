<section class="mh-testimonial" id="mh-testimonial">
   <div class="home-v-img">
      <div class="container">
         <div class="row section-separator">
            <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
               <h3>Client Reviews</h3>
            </div>
            <div class="col-sm-12 wow fadeInUp" id="mh-client-review" data-wow-duration="0.8s" data-wow-delay="0.3s">
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
               <div class="each-client-item">
                  <div class="mh-client-item dark-bg black-shadow-1">
                     <img src="http://cvresumetemplate.com/maha-personal-cv-resume-html-template/assets/images/c-1.png" alt="" class="img-fluid">
                     <p>Absolute wonderful ! I am completely
                        blown away.The very best.I was amazed
                        at the quality
                     </p>
                     <h4>John Mike</h4>
                     <span>CEO, Author.Inc</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/widget-testimonials.blade.php ENDPATH**/ ?>
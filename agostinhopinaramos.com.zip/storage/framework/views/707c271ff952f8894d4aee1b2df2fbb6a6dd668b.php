<?php $__env->startComponent('mail::message'); ?>
## Personal Website

<?php echo e($message); ?>


Thanks,<br/>
<?php echo e($name); ?>,<br/>
<?php echo e($email); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/emails/client.blade.php ENDPATH**/ ?>
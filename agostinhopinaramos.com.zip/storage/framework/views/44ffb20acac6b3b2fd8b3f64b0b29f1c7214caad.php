<?php if(count($internalCSS)>0 || count($externalCSS)>0): ?>
    <!-- Load STYLES -->
<?php $__currentLoopData = $externalCSS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e($path.$url); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $internalCSS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <style><?php echo $style; ?></style>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(count($internalJS)>0 || count($externalJS)>0): ?>
    <!-- Load JS -->
<?php $__currentLoopData = $externalJS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript" src="<?php echo e($path.$url); ?>" ></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $internalJS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript" ><?php echo $script; ?></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/footer.blade.php ENDPATH**/ ?>
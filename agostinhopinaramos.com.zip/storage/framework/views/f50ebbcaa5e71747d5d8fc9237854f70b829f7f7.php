<!DOCTYPE html>
<html lang="<?php echo e($lang); ?>">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <meta name="author" content="<?php echo e($author); ?>">
     <?php if (isset($component)) { $__componentOriginal1d34bd39c0afd63aba022a60d3edd3f92845cf07 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HtmlFavicon::class, []); ?>
<?php $component->withName('Html-Favicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1d34bd39c0afd63aba022a60d3edd3f92845cf07)): ?>
<?php $component = $__componentOriginal1d34bd39c0afd63aba022a60d3edd3f92845cf07; ?>
<?php unset($__componentOriginal1d34bd39c0afd63aba022a60d3edd3f92845cf07); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <title><?php echo e($title); ?></title>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-DLK0YQS3WW"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-DLK0YQS3WW');
</script>
<!-- END Global site tag (gtag.js) - Google Analytics -->
<?php if(count($externalFONT)>0): ?>
    <!-- Load FONTS -->
<?php $__currentLoopData = $externalFONT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e($url); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($externalCSS)>0): ?>
    <!-- Load STYLES -->
<?php $__currentLoopData = $externalCSS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e($url); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($externalJS)>0): ?>
    <!-- Load JS -->
<?php $__currentLoopData = $externalJS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript" src="<?php echo e($url); ?>" ></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</head>
<body class="<?php echo e($themeClass); ?>" ><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/header.blade.php ENDPATH**/ ?>
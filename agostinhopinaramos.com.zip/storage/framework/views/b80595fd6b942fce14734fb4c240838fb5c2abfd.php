<?php
    $manifest_directory =  __DIR__ . "/../../../public" . '/storage/project/manifest/';
    $manifest = file_get_contents( $manifest_directory . $id . '.json' );
    $article = json_decode($manifest, true);
?>
<header id="demo-header">
    <?php if($type == 'webapplication'): ?>
    <div class="details">
      <div class="inner">
         <h1><?php echo e($article["title"]); ?></h1>
         <p class="description"><?php echo e($article["subtitle"]); ?></p>
      </div>
   </div>
   <div id="demo-ad" class="ad">
      <div class="unit">
         <div >
            <div style="width: 728px;">
                <!-- ADS -->
            </div>
         </div>
      </div>
   </div>
   <ul class="actions">
    <li>
        <a href="<?php echo e($article["more"]["download"]); ?>" class="btn">
            <i class="fa fa-download"></i> Download (<?php echo e($article["size"]); ?>)
        </a>
    </li>
    <li>
        <a href="/" class="button">
            <i class="fa fa-home"></i>
        </a>
    </li>
    <li>
        <a href="prev" class="button">
            <i class="fa fa-arrow-left"></i>
        </a>
    </li>
    <li>
        <a href="next" class="button">
            <i class="fa fa-arrow-right"></i>
        </a>
    </li>
   </ul>
   <?php endif; ?>
</header><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/widget-demo-header.blade.php ENDPATH**/ ?>
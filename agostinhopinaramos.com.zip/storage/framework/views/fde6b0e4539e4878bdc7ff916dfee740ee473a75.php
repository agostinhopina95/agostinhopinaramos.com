<section class="mh-experince" id="mh-experience">
   <div class="bolor-overlay">
      <div class="container">
         <div class="row section-separator">
            <div class="col-sm-12 col-md-6">
               <div class="mh-education">
                  <h3 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Education</h3>
                  <div class="mh-education-deatils">
                     <?php $__currentLoopData = $obj["experience"]["education"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <!-- Education Institutes-->
                     <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                        <h4><?php echo e($education["course"]); ?> - <a target="_blank"  href="<?php echo e($education["url"]); ?>"><?php echo e($education["name"]); ?></a></h4>
                        <div class="mh-eduyear"><?php echo e($education["address"]); ?></div>
                        <p><?php echo e($education["interval"]); ?></p>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
            </div>
            <div class="col-sm-12 col-md-6">
               <div class="mh-work">
                  <h3>Work Experience</h3>
                  <div class="mh-experience-deatils">
                     <?php $__currentLoopData = $obj["experience"]["work"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <!-- Education Institutes-->
                     <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                        <h4><?php echo e($work["area"]); ?> <a target="_blank" href="<?php echo e($work["url"]); ?>"><?php echo e($work["name"]); ?></a></h4>
                        <div class="mh-eduyear"><?php echo e($work["interval"]); ?></div>
                        <span>Responsibility :</span>
                        <ul class="work-responsibility">
                           <?php $__currentLoopData = $work["responsibility"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsibility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><i class="fa fa-circle"></i><?php echo e($responsibility); ?></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section><?php /**PATH C:\Users\GSC\Documents\GitHub\agostinhopinaramos.com\resources\views/components/widget-experiences.blade.php ENDPATH**/ ?>